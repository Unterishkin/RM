const express = require("express");
const router = express.Router();
const reviewController = require("../ctrl/ctrller");
router.post("/", reviewController.createReview);
router.delete("/:id", reviewController.deleteReview);
router.patch("/:id/moderate", reviewController.reviewModeration);
router.get("/product/:productId", reviewController.getProductReviews);
module.exports = router;
